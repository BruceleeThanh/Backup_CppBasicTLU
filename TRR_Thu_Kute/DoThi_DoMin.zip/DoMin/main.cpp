#include <iostream>
#include "DoMin.h"
using namespace std;
int main()
{
	DoMin dm;
	dm.KhoiTaoMaTranBanDau();
	dm.InMaTranBanDau();
	dm.NhapToaDo();
	return 0;
}
